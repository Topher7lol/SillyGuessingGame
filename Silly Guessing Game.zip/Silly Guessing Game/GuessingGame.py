import tkinter as tk
from tkinter import messagebox
import random
import os

print("Started Game.")

class GuessingGame:
    def __init__(self, master):
        self.master = master
        self.master.title("Astronomical Guessing Game")

        # Set the icon from the same directory as the script
        icon_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), "icon.ico")
        self.master.iconbitmap(icon_path)

        self.secret_number = random.randint(1, 100)
        self.attempts = 0

        self.label = tk.Label(master, text="Guess the number between 1 and 100:")
        self.label.pack(pady=10)

        self.entry = tk.Entry(master)
        self.entry.pack(pady=10)

        self.submit_button = tk.Button(master, text="Submit Guess", command=self.check_guess)
        self.submit_button.pack(pady=10)

    def check_guess(self):
        try:
            guess = int(self.entry.get())
            self.attempts += 1

            if guess < self.secret_number:
                messagebox.showinfo("Result", "Too low! Try again.")
                print("Too Low! Try Again!")
            elif guess > self.secret_number:
                messagebox.showinfo("Result", "Too high! Try again.")
                print("Too High! Try Again!")
            else:
                messagebox.showinfo("Congratulations!", f"You guessed the number in {self.attempts} attempts.")
                self.master.destroy()  # Close the GUI after guessing correctly
        except ValueError:
            messagebox.showerror("Error", "Please enter a valid number.")
            print("Error.")

if __name__ == "__main__":
    root = tk.Tk()
    game = GuessingGame(root)
    root.mainloop()
